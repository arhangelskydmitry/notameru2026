<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\AdminPanelController;
use App\Http\Controllers\RssController;
use App\Http\Controllers\Auth\AdminAuthController;

// Admin Authentication routes (без middleware)
Route::prefix('notaadmin')->group(function() {
    Route::get('/login', [AdminAuthController::class, 'showLoginForm'])->name('admin.login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');
});

// Admin Panel routes (требуют аутентификации)
Route::prefix('notaadmin')->middleware('admin.auth')->group(function() {
    Route::get('/', [AdminPanelController::class, 'dashboard'])->name('admin.dashboard');
    
    // Content Quality Dashboard
    Route::get('/content-quality', [AdminPanelController::class, 'contentQuality'])->name('admin.content-quality');
    
    // Posts management
    Route::get('/posts', [AdminPanelController::class, 'posts'])->name('admin.posts');
    Route::get('/posts/create', [AdminPanelController::class, 'createPost'])->name('admin.posts.create');
    Route::post('/posts/store', [AdminPanelController::class, 'storePost'])->name('admin.posts.store');
    Route::get('/posts/{id}/edit', [AdminPanelController::class, 'editPost'])->name('admin.posts.edit');
    Route::post('/posts/{id}/update', [AdminPanelController::class, 'updatePost'])->name('admin.posts.update');
    Route::get('/posts/{id}/delete', [AdminPanelController::class, 'deletePost'])->name('admin.posts.delete');
    Route::post('/posts/upload-image', [AdminPanelController::class, 'uploadImage'])->name('admin.posts.upload-image');
    
    // Pages management
    Route::get('/pages', [AdminPanelController::class, 'pages'])->name('admin.pages');
    Route::get('/pages/{id}/edit', [AdminPanelController::class, 'editPage'])->name('admin.pages.edit');
    Route::post('/pages/{id}/update', [AdminPanelController::class, 'updatePage'])->name('admin.pages.update');
    Route::get('/pages/{id}/delete', [AdminPanelController::class, 'deletePage'])->name('admin.pages.delete');
    
    // Categories management
    Route::get('/categories', [AdminPanelController::class, 'categories'])->name('admin.categories');
    Route::post('/categories/{id}/update', [AdminPanelController::class, 'updateCategory'])->name('admin.categories.update');
    
    // Menu management
    Route::get('/menu', [AdminPanelController::class, 'menu'])->name('admin.menu');
    Route::post('/menu/create', [AdminPanelController::class, 'createMenuItem'])->name('admin.menu.create');
    Route::post('/menu/{id}/update', [AdminPanelController::class, 'updateMenuItem'])->name('admin.menu.update');
    Route::get('/menu/{id}/delete', [AdminPanelController::class, 'deleteMenuItem'])->name('admin.menu.delete');
    
    // SEO Dashboard
    Route::get('/seo', function() {
        return view('admin.seo-dashboard');
    })->name('admin.seo');
    
    // Banners management
    Route::get('/banners', [App\Http\Controllers\BannerController::class, 'index'])->name('admin.banners');
    Route::get('/banners/create', [App\Http\Controllers\BannerController::class, 'create'])->name('admin.banners.create');
    Route::post('/banners', [App\Http\Controllers\BannerController::class, 'store'])->name('admin.banners.store');
    Route::get('/banners/{id}/edit', [App\Http\Controllers\BannerController::class, 'edit'])->name('admin.banners.edit');
    Route::post('/banners/{id}', [App\Http\Controllers\BannerController::class, 'update'])->name('admin.banners.update');
    Route::get('/banners/{id}/delete', [App\Http\Controllers\BannerController::class, 'destroy'])->name('admin.banners.delete');
    Route::get('/banners/{id}/statistics', [App\Http\Controllers\BannerController::class, 'statistics'])->name('admin.banners.statistics');
    Route::get('/banners/{id}/toggle', [App\Http\Controllers\BannerController::class, 'toggleStatus'])->name('admin.banners.toggle');
    Route::get('/banners/{id}/preview', [App\Http\Controllers\BannerController::class, 'preview'])->name('admin.banners.preview');
    
    // Users management
    Route::get('/users', [AdminPanelController::class, 'users'])->name('admin.users');
    Route::get('/users/{id}/edit', [AdminPanelController::class, 'editUser'])->name('admin.users.edit');
    Route::post('/users/{id}/update', [AdminPanelController::class, 'updateUser'])->name('admin.users.update');
    
    // Activity log
    Route::get('/activity-log', [AdminPanelController::class, 'activityLog'])->name('admin.activity-log');
    
    // Author statistics
    Route::get('/author-statistics', [AdminPanelController::class, 'authorStatistics'])->name('admin.author-statistics');
    
    // My statistics (for authors)
    Route::get('/my-statistics', [AdminPanelController::class, 'myStatistics'])->name('admin.my-statistics');
    
    // Profile
    Route::get('/profile', [AdminPanelController::class, 'profile'])->name('admin.profile');
    Route::post('/profile/update', [AdminPanelController::class, 'updateProfile'])->name('admin.profile.update');
    
    // Passwords management (только для суперадмина)
    Route::get('/passwords', [AdminPanelController::class, 'viewPasswords'])->name('admin.passwords');
    Route::post('/passwords/{id}/reset', [AdminPanelController::class, 'resetPassword'])->name('admin.passwords.reset');
    
    // Sitemap management
    Route::get('/sitemap', [SitemapController::class, 'admin'])->name('admin.sitemap');
    Route::post('/sitemap/regenerate', [SitemapController::class, 'regenerate'])->name('admin.sitemap.regenerate');
});

// Frontend routes
Route::get('/', [FrontendController::class, 'index'])->name('home');
Route::get('/category/{slug}', [FrontendController::class, 'category'])->name('category');
Route::get('/tag/{slug}', [FrontendController::class, 'tag'])->name('tag');
Route::get('/author/{id}', [FrontendController::class, 'author'])->name('author');

// Карта сайта
Route::get('/sitemap-html', [FrontendController::class, 'htmlSitemap'])->name('sitemap.html');

// Посты по датам
Route::get('/date/{date}', [FrontendController::class, 'postsByDate'])->name('posts.by-date')->where('date', '\d{4}-\d{2}-\d{2}');
Route::get('/archive/{year}', [FrontendController::class, 'postsByYear'])->name('posts.by-year')->where('year', '\d{4}');
Route::get('/archive/{year}/{month}', [FrontendController::class, 'postsByYearMonth'])->name('posts.by-year-month')->where(['year' => '\d{4}', 'month' => '\d{2}']);

// API для карты сайта
Route::get('/api/sitemap/months/{year}', [FrontendController::class, 'getSitemapMonths'])->name('api.sitemap.months');
Route::get('/api/sitemap/days/{year}/{month}', [FrontendController::class, 'getSitemapDays'])->name('api.sitemap.days');
Route::get('/api/sitemap/posts/{year}/{month}/{day}', [FrontendController::class, 'getSitemapPosts'])->name('api.sitemap.posts');

Route::get('/search', [FrontendController::class, 'search'])->name('search');
Route::get('/privacy', function() {
    return view('frontend.privacy');
})->name('privacy');

// SEO routes
Route::get('/sitemap.xml', [SitemapController::class, 'index']);
Route::get('/api/sitemap/load-year', [FrontendController::class, 'loadSitemapYear'])->name('api.sitemap.year');
Route::get('/robots.txt', [SitemapController::class, 'robots']);

// Posts by date routes (должны быть ПЕРЕД catch-all роутом)
Route::get('/posts/{year}', [FrontendController::class, 'postsByYear'])->name('posts.year')->where('year', '[0-9]{4}');
Route::get('/posts/{year}/{month}', [FrontendController::class, 'postsByMonth'])->name('posts.month')->where(['year' => '[0-9]{4}', 'month' => '[0-9]{2}']);
Route::get('/posts/{year}/{month}/{day}', [FrontendController::class, 'postsByDay'])->name('posts.day')->where(['year' => '[0-9]{4}', 'month' => '[0-9]{2}', 'day' => '[0-9]{2}']);

// RSS feeds
Route::get('/feed/zen1', [RssController::class, 'yandexZen'])->name('rss.yandex-zen');
Route::get('/feed/yandex-zen', [RssController::class, 'yandexZen']); // Альтернативный URL

// Яндекс.Новости
Route::get('/yandex/news', [RssController::class, 'yandexNews'])->name('rss.yandex-news');
Route::get('/index.php', function() {
    if (request('yandex_feed') === 'news') {
        return app(RssController::class)->yandexNews();
    }
    return redirect('/');
});

// Яндекс.Турбо
Route::get('/yandex/turbo', [RssController::class, 'yandexTurbo'])->name('rss.yandex-turbo');

// Catch-all для постов (должен быть ПОСЛЕДНИМ)
Route::get('/{slug}', [FrontendController::class, 'post'])->name('post')->where('slug', '^(?!api|admin|notaadmin|sitemap|robots|privacy|feed|yandex|index\.php).*');

// API routes with rate limiting
Route::prefix('api')->middleware('throttle:120,1')->group(function() {
    // Posts
    Route::get('/posts', [\App\Http\Controllers\Api\PostController::class, 'index']);
    Route::get('/posts/latest', [\App\Http\Controllers\Api\PostController::class, 'latest']);
    Route::get('/posts/popular', [\App\Http\Controllers\Api\PostController::class, 'popular']);
    Route::get('/posts/{id}', [\App\Http\Controllers\Api\PostController::class, 'show']);
    
    // Categories
    Route::get('/categories', [\App\Http\Controllers\Api\CategoryController::class, 'index']);
    Route::get('/categories/{id}', [\App\Http\Controllers\Api\CategoryController::class, 'show']);
    
    // Tags
    Route::get('/tags', [\App\Http\Controllers\Api\TagController::class, 'index']);
    Route::get('/tags/popular', [\App\Http\Controllers\Api\TagController::class, 'popular']);
    Route::get('/tags/{id}', [\App\Http\Controllers\Api\TagController::class, 'show']);
    
    // Lazy loading
    Route::get('/load-more-posts', [FrontendController::class, 'loadMorePosts']);
    
    // Smart search suggestions
    Route::get('/search-suggestions', [FrontendController::class, 'searchSuggestions']);
    
    // Banner tracking
    Route::post('/banner/impression', [App\Http\Controllers\BannerController::class, 'trackImpression']);
    Route::post('/banner/click', [App\Http\Controllers\BannerController::class, 'trackClick']);
});

// Fallback route for 404 errors
Route::fallback([FrontendController::class, 'notFound']);

