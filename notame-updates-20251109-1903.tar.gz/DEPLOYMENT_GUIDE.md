# 🚀 ИНСТРУКЦИЯ ПО ДЕПЛОЮ НА СЕРВЕР

## 📋 ЧТО НУЖНО ЗАКАЧАТЬ НА СЕРВЕР

### 1️⃣ ФАЙЛЫ ПРОЕКТА

#### Обязательные файлы и папки:
```
├── app/                          # ✅ ВСЕ файлы приложения
├── bootstrap/                    # ✅ Bootstrap Laravel
├── config/                       # ✅ Конфигурационные файлы
├── database/                     # ✅ Миграции и сиды
├── public/                       # ✅ Публичная папка (DocumentRoot)
│   ├── .htaccess                 # ⚠️  ВАЖНО! Редирект www
│   ├── index.php
│   ├── css/
│   ├── js/
│   ├── images/
│   └── imgnews/                  # ⚠️  Изображения (если есть новые WebP)
├── resources/                    # ✅ Views, CSS, JS
├── routes/                       # ✅ Роуты (web.php обновлен)
├── storage/                      # ⚠️  См. ниже
│   ├── app/
│   ├── framework/                # ⚠️  НЕ загружать cache/sessions
│   └── logs/                     # ⚠️  НЕ загружать старые логи
├── vendor/                       # ⚠️  НЕ загружать! Запустить composer install
├── .env                          # ⚠️  Настроить для production
├── artisan
├── composer.json                 # ✅ Обновлен (без MoonShine)
├── composer.lock
└── package.json
```

---

## 🔧 ПОШАГОВАЯ ИНСТРУКЦИЯ

### ШАГ 1: Подготовка файлов

#### A. Создать архив измененных файлов
```bash
cd /Users/mac/Sites/notamerularavel

# Создаем архив ТОЛЬКО измененных файлов
tar -czf notame-updates-$(date +%Y%m%d).tar.gz \
  app/Console/Commands/ \
  app/Http/Controllers/FrontendController.php \
  app/Http/Controllers/SitemapController.php \
  app/Models/WordPress/Post.php \
  resources/views/frontend/index.blade.php \
  resources/views/frontend/404.blade.php \
  routes/web.php \
  public/.htaccess \
  composer.json \
  composer.lock

echo "✅ Архив создан: notame-updates-$(date +%Y%m%d).tar.gz"
```

#### B. Список новых команд Artisan
```
app/Console/Commands/CleanWordPressRevisions.php     ← Очистка ревизий
app/Console/Commands/OptimizeDiskImages.php          ← Конвертация изображений
app/Console/Commands/BackupDatabase.php              ← Резервные копии
app/Console/Commands/CleanUnusedWordPressTables.php ← Очистка таблиц
app/Console/Commands/RemoveMoonShine.php             ← Удаление MoonShine
```

---

### ШАГ 2: Загрузка на сервер

#### Вариант A: Через Git (РЕКОМЕНДУЕТСЯ)
```bash
# На локальной машине
git add .
git commit -m "feat: добавлена 404 страница, оптимизация, featured images"
git push origin main

# На сервере
cd /path/to/notame.ru
git pull origin main
```

#### Вариант B: Через FTP/SFTP
1. Загрузите архив `notame-updates-*.tar.gz` на сервер
2. Распакуйте:
```bash
cd /path/to/notame.ru
tar -xzf notame-updates-*.tar.gz
```

---

### ШАГ 3: На сервере - Установка зависимостей

```bash
cd /path/to/notame.ru

# 1. Установить Composer зависимости (без MoonShine)
composer install --no-dev --optimize-autoloader

# 2. Очистить кэш Laravel
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# 3. Оптимизировать для production
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

---

### ШАГ 4: Настройка .env для Production

```env
APP_NAME="Нота Миру"
APP_ENV=production
APP_DEBUG=false                    # ⚠️  ОБЯЗАТЕЛЬНО false
APP_URL=https://notame.ru

# База данных (проверьте настройки)
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ваша_база
DB_USERNAME=ваш_юзер
DB_PASSWORD=ваш_пароль

# Кэш, сессии, очереди
CACHE_DRIVER=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync

# Логирование
LOG_CHANNEL=stack
LOG_LEVEL=error                    # ⚠️  Только ошибки в production
```

---

### ШАГ 5: Настройка прав доступа

```bash
# Права на storage и bootstrap/cache
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache

# Или если другой пользователь
chown -R your-user:www-data storage bootstrap/cache
```

---

### ШАГ 6: Проверка .htaccess

Убедитесь, что `public/.htaccess` содержит редирект www:

```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews -Indexes
    </IfModule>

    RewriteEngine On

    # Redirect www to non-www
    RewriteCond %{HTTP_HOST} ^www\.(.*)$ [NC]
    RewriteRule ^(.*)$ https://%1/$1 [R=301,L]

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
    
    # ... остальные правила ...
</IfModule>
```

---

### ШАГ 7: Настройка Apache/Nginx

#### Apache (если используется)
DocumentRoot должен указывать на `public/`:
```apache
<VirtualHost *:80>
    ServerName notame.ru
    ServerAlias www.notame.ru
    DocumentRoot /path/to/notame.ru/public
    
    <Directory /path/to/notame.ru/public>
        AllowOverride All
        Require all granted
    </Directory>
    
    # Редирект на HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    ServerName notame.ru
    ServerAlias www.notame.ru
    DocumentRoot /path/to/notame.ru/public
    
    SSLEngine on
    SSLCertificateFile /path/to/cert.pem
    SSLCertificateKeyFile /path/to/key.pem
    
    <Directory /path/to/notame.ru/public>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

---

### ШАГ 8: Конвертация изображений на сервере (опционально)

Если хотите конвертировать изображения на сервере:

```bash
# Проверить, есть ли поддержка WebP
php -r "echo function_exists('imagewebp') ? 'WebP ✅' : 'WebP ❌';"

# Если есть, запустить конвертацию партиями
nohup php artisan images:optimize-disk --limit=5000 --quality=82 --force > storage/logs/webp-conversion.log 2>&1 &

# Мониторить прогресс
tail -f storage/logs/webp-conversion.log
```

---

### ШАГ 9: Проверка работоспособности

#### 1. Проверить главную страницу
```bash
curl -I https://notame.ru
# Должен быть 200 OK
```

#### 2. Проверить редирект www
```bash
curl -I https://www.notame.ru
# Должен быть 301 Moved Permanently → https://notame.ru
```

#### 3. Проверить страницу 404
```bash
curl -I https://notame.ru/несуществующая-страница
# Должен быть 404 Not Found
```

#### 4. Проверить Open Graph
Откройте в браузере и проверьте meta-теги:
```
https://notame.ru
```
Должны быть:
- `<meta property="og:image" content="...">` с изображением последней новости
- `<meta name="twitter:image" content="...">` с изображением

#### 5. Тест шаринга в соцсетях
- Facebook Debugger: https://developers.facebook.com/tools/debug/
- Twitter Card Validator: https://cards-dev.twitter.com/validator
- VK: https://vk.com/dev/share_preview

---

## ⚠️ ВАЖНО: ЧТО НЕ НУЖНО ЗАГРУЖАТЬ

```
❌ /vendor/                    # Устанавливается через composer install
❌ /node_modules/              # Устанавливается через npm install
❌ /storage/logs/*.log         # Старые логи не нужны
❌ /storage/framework/cache/*  # Кэш пересоздается
❌ /storage/framework/sessions/* # Сессии пересоздаются
❌ /.git/                      # Если не используете Git на сервере
❌ /.env.example               # Только .env нужен
```

---

## 🔄 ФАЙЛЫ, КОТОРЫЕ ТОЧНО ИЗМЕНИЛИСЬ

### Обязательно загрузить:
1. ✅ `app/Console/Commands/` - **5 новых команд**
2. ✅ `app/Http/Controllers/FrontendController.php` - метод `notFound()`
3. ✅ `app/Http/Controllers/SitemapController.php` - исправлен метод `stats()`
4. ✅ `app/Models/WordPress/Post.php` - добавлены `getFeaturedImageAttribute()`, `getSocialImageAttribute()`
5. ✅ `resources/views/frontend/404.blade.php` - **НОВЫЙ ФАЙЛ**
6. ✅ `resources/views/frontend/index.blade.php` - обновлен og_image
7. ✅ `routes/web.php` - добавлен `Route::fallback()`
8. ✅ `public/.htaccess` - добавлен редирект www
9. ✅ `composer.json` - удален MoonShine
10. ✅ `composer.lock` - обновлен

---

## 🎯 БЫСТРЫЙ ЧЕКЛИСТ

```bash
# 1. Загрузить файлы на сервер
[ ] Загружены измененные файлы

# 2. На сервере
[ ] composer install --no-dev --optimize-autoloader
[ ] php artisan cache:clear
[ ] php artisan config:cache
[ ] php artisan route:cache
[ ] php artisan view:cache

# 3. Проверить права
[ ] chmod -R 775 storage bootstrap/cache
[ ] chown -R user:www-data storage bootstrap/cache

# 4. Проверить .env
[ ] APP_ENV=production
[ ] APP_DEBUG=false
[ ] APP_URL=https://notame.ru

# 5. Проверить работу
[ ] Главная страница загружается
[ ] Редирект www → non-www работает
[ ] Страница 404 отображается
[ ] Open Graph изображения в meta-тегах
```

---

## 🆘 РЕШЕНИЕ ПРОБЛЕМ

### Проблема: "Class not found"
```bash
composer dump-autoload
php artisan clear-compiled
php artisan cache:clear
```

### Проблема: "Route not found"
```bash
php artisan route:clear
php artisan route:cache
```

### Проблема: "View not found"
```bash
php artisan view:clear
php artisan view:cache
```

### Проблема: Изображения не отображаются
```bash
# Проверить права
ls -la public/imgnews/
chmod -R 755 public/imgnews/
```

### Проблема: 404 страница не работает
```bash
# Проверить роут
php artisan route:list | grep fallback

# Должен быть:
# GET|HEAD|POST|PUT|PATCH|DELETE|OPTIONS  {fallback}  App\Http\Controllers\FrontendController@notFound
```

---

## 📞 ПОДДЕРЖКА

После деплоя проверьте логи:
```bash
tail -f storage/logs/laravel.log
```

---

**Готово! 🎉 Все должно работать после выполнения этих шагов.**

